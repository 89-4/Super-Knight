
import main
print (help(main))